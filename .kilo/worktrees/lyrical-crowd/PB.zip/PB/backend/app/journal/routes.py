# backend/app/journal/routes.py
from fastapi import APIRouter, HTTPException
from app.utils.db import db
from app.journal.models import JournalEntry
from app.utils.bert_emotion_api import detect_emotion
from datetime import datetime
from app.utils.db import get_db

router = APIRouter()



@router.post("/")
def add_entry(entry: JournalEntry):
    try:
        db = get_db()
        journals = db["journals"]
        print("📥 Incoming Entry:", entry.dict())  
        data = entry.dict()
        
        # Add timestamp if not present
        if "timestamp" not in data or not data["timestamp"]:
            data["timestamp"] = datetime.utcnow()
        
        # Detect emotion from content
        emotion_data = detect_emotion(data["content"])
        data["emotion"] = emotion_data["emotion"]
        data["emotion_score"] = emotion_data["score"]

        result = journals.insert_one(data)
        print("✅ Insert Result:", result.inserted_id)

        # Return complete entry for frontend
        return {
            "_id": str(result.inserted_id),
            "username": data["username"],
            "title": data["title"],
            "content": data["content"],
            "timestamp": data["timestamp"],
            "emotion": data["emotion"],
            "emotion_score": data["emotion_score"]
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{username}")
def get_entries(username: str):
    try:
        db = get_db()
        journals = db["journals"]
        entries = list(journals.find({"username": username}).sort("timestamp", -1))
        for e in entries:
            e["_id"] = str(e["_id"])
        return entries
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Fetching journal failed: {e}")
