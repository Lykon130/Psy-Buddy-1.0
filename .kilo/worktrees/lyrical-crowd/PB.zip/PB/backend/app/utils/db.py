# backend/app/utils/db.py
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from app.config import MONGO_URI, DB_NAME

client = None
db = None


def get_db():
    """Returns the connected DB instance."""
    global db
    if db is None:
        raise RuntimeError("Database not initialized. Call connect_to_mongo() first.")
    return db


def connect_to_mongo():
    """Connect to MongoDB and set the global db object."""
    global client, db
    try:
        # Try TLS connection first, fallback to non-TLS if fails
        try:
            client = MongoClient(
                MONGO_URI,
                tls=True,
                tlsAllowInvalidCertificates=False,
                serverSelectionTimeoutMS=20000
            )
            client.admin.command("ping")
            print("✅ MongoDB connected with TLS.")
        except Exception:
            print("⚠️ TLS connection failed. Retrying without TLS...")
            client = MongoClient(
                MONGO_URI,
                serverSelectionTimeoutMS=20000
            )
            client.admin.command("ping")
            print("✅ MongoDB connected without TLS.")

        db = client[DB_NAME]
        print(f"📦 Using database: {DB_NAME}")

        # Ensure collections exist
        ensure_collections()

    except PyMongoError as e:
        print(f"❌ MongoDB Connection Error: {e}")
        raise e


def ensure_collections():
    """Ensure all required collections exist."""
    if db is None:
        raise RuntimeError("Database not initialized. Call connect_to_mongo() first.")

    required_collections = ["users", "journal", "chats", "dreams"]
    existing_collections = db.list_collection_names()

    for coll in required_collections:
        if coll not in existing_collections:
            db.create_collection(coll)
            print(f"✅ '{coll}' collection created.")
        else:
            print(f"ℹ️ '{coll}' collection already exists.")
