# backend/app/config.py

# Configuration for PsyBuddy backend
MONGO_URI = "mongodb+srv://2023ab05062:2023ab05062@psybuddycluster.fqwhfmv.mongodb.net/"
DB_NAME = "psybuddy_db"

JWT_SECRET = "PsyBuddy"  # Change to your own secure key
JWT_ALGORITHM = "HS256"

OPENAI_API_KEY = "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"  # Replace with your OpenAI key
