# backend/app/mood/routes.py
from fastapi import APIRouter, HTTPException, Query
from app.utils.db import get_db
from collections import Counter
from datetime import datetime, timedelta
from bson.son import SON

router = APIRouter()

@router.get("/{username}")
async def get_mood_data(
    username: str,
    days: int = Query(7, ge=0, le=365, description="Number of days to look back (0 = all time)")
):
    """
    Fetch mood totals and daily trends for a user.
    - totals: counts of each emotion
    - trend: {date: {emotion: count}}
    """
    try:
        db = get_db()
        chats = db["chats"]

        # Base query: only user messages with emotion
        filter_query = {
            "username": username,
            "role": "user",
            "emotion": {"$exists": True, "$ne": None}
        }

        # Add cutoff date if days > 0
        if days > 0:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            filter_query["timestamp"] = {"$gte": cutoff_date}

        # 1. Totals
        conversations = list(chats.find(filter_query, {"emotion": 1, "_id": 0}))
        emotions = [c["emotion"] for c in conversations if "emotion" in c]
        mood_counts = dict(Counter(emotions))

        # 2. Daily trend
        pipeline = [
            {"$match": filter_query},
            {
                "$group": {
                    "_id": {
                        "date": {
                            "$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}
                        },
                        "emotion": "$emotion"
                    },
                    "count": {"$sum": 1}
                }
            },
            {"$sort": SON([("_id.date", 1)])}
        ]

        trend_data_raw = list(chats.aggregate(pipeline))

        # Transform into {date: {emotion: count}}
        trend_data = {}
        for entry in trend_data_raw:
            date = entry["_id"]["date"]
            emotion = entry["_id"]["emotion"]
            count = entry["count"]

            if date not in trend_data:
                trend_data[date] = {}
            trend_data[date][emotion] = count

        return {"totals": mood_counts, "trend": trend_data}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Fetching mood data failed: {e}")
