# backend/app/auth/routes.py
from fastapi import APIRouter, HTTPException
from pymongo.errors import PyMongoError
from passlib.hash import bcrypt
from jose import jwt
from datetime import datetime, timedelta

from app.utils.db import get_db, connect_to_mongo, ensure_collections
from app.auth.models import UserRegister

# JWT settings
SECRET_KEY = "your_secret_key"  # 🔹 Change this to something secure
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

router = APIRouter()

# ---------------------------
# Register Route
# ---------------------------
@router.post("/register")
def register(user: UserRegister):
    try:
        # Ensure DB connection
        try:
            db = get_db()
        except RuntimeError:
            connect_to_mongo()
            ensure_collections()
            db = get_db()

        # Check if username exists
        if db.users.find_one({"username": user.username}):
            raise HTTPException(status_code=400, detail="Username already exists.")

        # Hash password before saving
        hashed_password = bcrypt.hash(user.password)
        db.users.insert_one({
            "username": user.username,
            "password": hashed_password
        })

        return {"message": "User registered successfully."}

    except PyMongoError as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")


# ---------------------------
# Login Route
# ---------------------------
@router.post("/login")
def login(user: UserRegister):
    try:
        # Ensure DB connection
        try:
            db = get_db()
        except RuntimeError:
            connect_to_mongo()
            ensure_collections()
            db = get_db()

        # Find user
        db_user = db.users.find_one({"username": user.username})
        if not db_user or not bcrypt.verify(user.password, db_user["password"]):
            raise HTTPException(status_code=401, detail="Invalid username or password.")

        # Create JWT token
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        payload = {
            "sub": user.username,
            "exp": expire
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

        return {
            "access_token": token,
            "token_type": "bearer",
            "username": user.username
        }

    except PyMongoError as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")
