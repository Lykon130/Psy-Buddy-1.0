# backend/app/dreams/routes.py
from fastapi import APIRouter, HTTPException
from app.utils.db import get_db
from app.dreams.models import DreamEntry
from app.utils.bert_emotion_api import detect_emotion
from datetime import datetime

router = APIRouter()

@router.post("/")
async def add_dream(entry: DreamEntry):
    try:
        db = get_db()
        dreams = db["dreams"]

        # ✅ Emotion detection
        try:
            emotion_result = detect_emotion(text=entry.content)
            emotion = emotion_result.get("emotion", None)
        except Exception:
            emotion = None

        dream_doc = entry.dict()
        dream_doc["emotion"] = emotion
        dream_doc["timestamp"] = datetime.utcnow()

        result = dreams.insert_one(dream_doc)   # ❌ no await here
        dream_doc["_id"] = str(result.inserted_id)

        return dream_doc
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Saving dream failed: {e}")


@router.get("/{username}")
async def get_dreams(username: str):
    try:
        db = get_db()
        dreams = db["dreams"]

        # ❌ remove await and to_list
        entries = list(dreams.find({"username": username}).sort("timestamp", -1))
        for e in entries:
            e["_id"] = str(e["_id"])
        return entries
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Fetching dreams failed: {e}")
