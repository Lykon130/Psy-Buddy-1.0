from fastapi import APIRouter, HTTPException
from bson import ObjectId
from datetime import datetime
import uuid
import motor.motor_asyncio

from .models import Conversation, ChatMessage, ChatRequest
from app.utils.bert_emotion_api import detect_emotion
from app.chat.gpt_service import get_ai_response

router = APIRouter()

# MongoDB setup
client = motor.motor_asyncio.AsyncIOMotorClient("mongodb://localhost:27017")
db = client.psybuddy
chat_collection = db.chats


# Helper
def fix_id(record):
    record["_id"] = str(record["_id"])
    return record


@router.post("/")
async def chat(request: ChatRequest):
    try:
        session_id = request.session_id or str(uuid.uuid4())

        # Emotion detection
        try:
            emotion_result = detect_emotion(text=request.message)
            emotion = emotion_result.get("emotion", None)
        except Exception as e:
            emotion = None
            print(f"[Emotion Detection Error] {e}")

        # Fetch all messages for user (all sessions)
        all_messages = await chat_collection.find(
            {"username": request.username}
        ).sort("timestamp", 1).to_list(length=None)

        history_for_gpt = [
            {"role": msg["role"], "content": msg["content"]}
            for msg in all_messages
        ]
        history_for_gpt.append({"role": "user", "content": request.message})

        # Get AI reply
        reply = get_ai_response(history_for_gpt, request.persona)

        # If session is new, generate title
        existing_session = await chat_collection.find_one(
            {"username": request.username, "session_id": session_id}
        )
        session_title = None
        if not existing_session:
            session_title = request.message[:40] + ("..." if len(request.message) > 40 else "")

        # Save user message
        user_doc = ChatMessage(
            username=request.username,
            role="user",
            content=request.message,
            emotion=emotion,
            persona=request.persona,
            session_id=session_id,
            timestamp=datetime.utcnow()
        ).dict()
        if session_title:
            user_doc["session_title"] = session_title
        await chat_collection.insert_one(user_doc)

        # Save assistant reply
        assistant_doc = ChatMessage(
            username=request.username,
            role="assistant",
            content=reply,
            persona=request.persona,
            session_id=session_id,
            timestamp=datetime.utcnow()
        ).dict()
        await chat_collection.insert_one(assistant_doc)

        return {
            "reply": reply,
            "emotion": emotion,
            "session_id": session_id
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chat failed: {e}")


@router.get("/history/{username}")
async def get_all_history(username: str):
    try:
        sessions = await chat_collection.aggregate([
            {"$match": {"username": username}},
            {"$group": {
                "_id": "$session_id",
                "messages": {"$push": "$$ROOT"},
                "last_updated": {"$max": "$timestamp"},
                "title": {"$first": "$session_title"}
            }},
            {"$sort": {"last_updated": -1}}
        ]).to_list(length=None)

        for s in sessions:
            s["session_id"] = s["_id"]
            del s["_id"]
            s["messages"] = [fix_id(m) for m in s["messages"]]
            if not s.get("title"):
                s["title"] = f"Chat {s['session_id'][:6]}"

        return sessions

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Fetching history failed: {e}")


@router.get("/history/{username}/{session_id}")
async def get_session_history(username: str, session_id: str):
    try:
        messages = await chat_collection.find(
            {"username": username, "session_id": session_id}
        ).sort("timestamp", 1).to_list(length=None)
        return [fix_id(m) for m in messages]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Fetching session history failed: {e}")
