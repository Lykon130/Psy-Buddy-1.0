// lib/screens/mood_screen.dart
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class MoodScreen extends StatefulWidget {
  final String username;
  const MoodScreen({super.key, required this.username});

  @override
  State<MoodScreen> createState() => _MoodScreenState();
}

class _MoodScreenState extends State<MoodScreen> {
  final List<Map<String, dynamic>> _dayOptions = [
    {"label": "Last 7 Days", "value": 7},
    {"label": "Last 30 Days", "value": 30},
    {"label": "Last 90 Days", "value": 90},
    {"label": "All Time", "value": 0},
  ];

  int _selectedDays = 7;
  bool _loading = false;
  Map<String, dynamic>? _moodData;

  @override
  void initState() {
    super.initState();
    _fetchMood();
  }

  Future<void> _fetchMood() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.fetchMoodData(
        widget.username,
        days: _selectedDays,
      );
      setState(() {
        _moodData = data;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  Widget _buildTotals() {
    final totals = _moodData?["totals"] as Map<String, dynamic>? ?? {};
    if (totals.isEmpty) {
      return const Text("No mood totals available.");
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: totals.entries.map((e) {
        return Text("${e.key}: ${e.value}",
            style: const TextStyle(fontSize: 16));
      }).toList(),
    );
  }

  Widget _buildTrends() {
    final trend = _moodData?["trend"] as Map<String, dynamic>? ?? {};
    if (trend.isEmpty) {
      return const Text("No daily trend data available.");
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: trend.entries.map((dateEntry) {
        final date = dateEntry.key;
        final emotions = dateEntry.value as Map<String, dynamic>;
        final emotionsStr = emotions.entries
            .map((e) => "${e.key}: ${e.value}")
            .join(", ");
        return Text("$date → $emotionsStr",
            style: const TextStyle(fontSize: 14));
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Mood Trends")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButton<int>(
              value: _selectedDays,
              isExpanded: true,
              onChanged: (value) {
                if (value != null) {
                  setState(() => _selectedDays = value);
                  _fetchMood();
                }
              },
              items: _dayOptions.map((opt) {
                return DropdownMenuItem<int>(
                  value: opt["value"],
                  child: Text(opt["label"]),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            _loading
                ? const CircularProgressIndicator()
                : Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Mood Totals",
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          _buildTotals(),
                          const SizedBox(height: 20),
                          const Text("Daily Trends",
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          _buildTrends(),
                        ],
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
