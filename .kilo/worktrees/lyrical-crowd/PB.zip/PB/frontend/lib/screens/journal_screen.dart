import 'package:flutter/material.dart';
import '../models/journal_entry.dart';
import '../services/api_service.dart';
import 'login_screen.dart';
import 'mood_chart_screen.dart';

class JournalScreen extends StatefulWidget {
  final String username;
  const JournalScreen({super.key, required this.username});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  List<JournalEntry> entries = [];
  bool _loading = true;
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    try {
      final data = await ApiService.fetchJournalEntries(widget.username);
      setState(() {
        entries = data;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _addEntry() async {
    if (_titleController.text.trim().isEmpty || _contentController.text.trim().isEmpty) return;
    try {
      final entry = await ApiService.addJournalEntry(
        widget.username,
        _titleController.text.trim(),
        _contentController.text.trim(),
      );
      setState(() {
        entries.insert(0, entry);
      });
      _titleController.clear();
      _contentController.clear();
      Navigator.pop(context);
    } catch (e) {
      debugPrint("Error adding journal: $e");
    }
  }

  void _showAddEntryDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("New Journal Entry"),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: "Title"),
              ),
              TextField(
                controller: _contentController,
                decoration: const InputDecoration(labelText: "Content"),
                maxLines: 5,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(onPressed: _addEntry, child: const Text("Add")),
        ],
      ),
    );
  }

  Widget _buildEntry(JournalEntry entry) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      child: ListTile(
        title: Text(entry.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(entry.content),
            const SizedBox(height: 4),
            Text("Emotion: ${entry.emotion}", style: const TextStyle(color: Colors.blue)),
          ],
        ),
        trailing: Text(
          "${entry.timestamp.toLocal()}".split(' ')[0],
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ),
    );
  }

  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  void _goToMoodChart() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MoodScreen(username: widget.username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Journal"),
        actions: [
          IconButton(icon: const Icon(Icons.show_chart), onPressed: _goToMoodChart),
          IconButton(icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: entries.length,
              itemBuilder: (_, i) => _buildEntry(entries[i]),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddEntryDialog,
        child: const Icon(Icons.add),
      ),
    );
  }
}
