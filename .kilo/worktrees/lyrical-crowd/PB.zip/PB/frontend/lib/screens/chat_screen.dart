import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/chat_message.dart';
import 'login_screen.dart';
import 'mood_chart_screen.dart';

class ChatScreen extends StatefulWidget {
  final String username;
  final String persona; // initial persona

  const ChatScreen({
    super.key,
    required this.username,
    required this.persona,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  List<Map<String, dynamic>> sessions = [];
  String? activeSessionId;
  List<ChatMessage> messages = [];
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool isLoading = false;

  late String currentPersona; // dynamic persona state

  @override
  void initState() {
    super.initState();
    currentPersona = widget.persona;
    _loadSessions();
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  Future<void> _loadSessions() async {
    try {
      final data = await ApiService.fetchChatSessions(widget.username);
      setState(() {
        sessions = data;
      });
    } catch (e) {
      _showError("Failed to load sessions");
    }
  }

  Future<void> _loadMessages(String sessionId) async {
    try {
      final msgs = await ApiService.fetchSessionMessages(
        widget.username,
        sessionId,
      );
      setState(() {
        activeSessionId = sessionId;
        messages = msgs;
      });
      _scrollToBottom();
    } catch (e) {
      _showError("Failed to load messages");
    }
  }

  Future<void> _sendMessage() async {
    if (_controller.text.trim().isEmpty || isLoading) return;
    final userMessage = _controller.text.trim();

    setState(() {
      messages.add(ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        sender: "user",
        message: userMessage,
        timestamp: DateTime.now(),
        isUser: true,
      ));
      _controller.clear();
      isLoading = true;
    });
    _scrollToBottom();

    try {
      final res = await ApiService.sendChatMessage(
        username: widget.username,
        message: userMessage,
        persona: currentPersona, // dynamic persona
        sessionId: activeSessionId,
      );

      setState(() {
        if (res.containsKey('session_id')) {
          activeSessionId = res['session_id'];
        }
        messages.add(ChatMessage(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          sender: "assistant",
          message: res['reply'] ?? '',
          timestamp: DateTime.now(),
          isUser: false,
        ));
      });
      _scrollToBottom();
      _loadSessions();
    } catch (e) {
      _showError("Failed to send message");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent + 100,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _startNewSession() {
    setState(() {
      activeSessionId = null;
      messages = [];
    });
  }

  Widget _buildSidebar() {
    return Container(
      width: 250,
      color: Colors.grey.shade900,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.black87),
            child: Text(
              "💬 Chat Sessions",
              style: TextStyle(fontSize: 18, color: Colors.white),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.add, color: Colors.white),
            title: const Text("New Chat",
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            onTap: _startNewSession,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: sessions.length,
              itemBuilder: (context, index) {
                final session = sessions[index];
                final isActive = session['session_id'] == activeSessionId;
                return ListTile(
                  tileColor:
                      isActive ? Colors.blue.shade700 : Colors.transparent,
                  title: Text(
                    session['title']?.isNotEmpty == true
                        ? session['title']
                        : 'Untitled Session',
                    style: TextStyle(
                      color: isActive ? Colors.white : Colors.grey.shade300,
                    ),
                  ),
                  onTap: () => _loadMessages(session['session_id']),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatArea() {
    return Expanded(
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(8),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isUser = msg.isUser;

                // Different bubble colors
                Color bubbleColor;
                if (isUser) {
                  bubbleColor = Colors.blueAccent;
                } else if (currentPersona == "empath") {
                  bubbleColor = Colors.deepPurpleAccent;
                } else {
                  bubbleColor = Colors.green.shade700;
                }

                return Align(
                  alignment:
                      isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: bubbleColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      msg.message,
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                );
              },
            ),
          ),
          if (isLoading)
            const Padding(
              padding: EdgeInsets.all(8),
              child: CircularProgressIndicator(),
            ),
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.grey.shade900,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: "Type a message...",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 8),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.send,
                    color: isLoading ? Colors.grey : Colors.blueAccent,
                  ),
                  onPressed: isLoading ? null : _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _togglePersona() {
    setState(() {
      currentPersona = currentPersona == "empath" ? "coach" : "empath";
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Persona switched to $currentPersona"),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  void _goToMoodChart() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MoodScreen(username: widget.username)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat (${currentPersona.toUpperCase()})"),
        actions: [
          IconButton(
              icon: const Icon(Icons.switch_account), onPressed: _togglePersona),
          IconButton(icon: const Icon(Icons.show_chart), onPressed: _goToMoodChart),
          IconButton(icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      body: Row(
        children: [
          _buildSidebar(),
          _buildChatArea(),
        ],
      ),
    );
  }
}
